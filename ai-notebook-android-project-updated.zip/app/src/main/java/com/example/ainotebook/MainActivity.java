package com.example.ainotebook;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.Manifest;
import android.graphics.Color;
import android.graphics.Typeface;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.media.MediaRecorder;
import android.media.MediaPlayer;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ArrayList;
import java.util.Locale;
import java.util.regex.Pattern;

public class MainActivity extends Activity {
    private static final int REQ_SPEECH = 42;
    private static final int REQ_AUDIO = 43;
    private EditText topicInput, notesInput;
    private TextView status;
    private SharedPreferences prefs;
    private String currentTopic = "My Notes";
    private MediaRecorder recorder;
    private MediaPlayer player;
    private File currentRecording;
    private TextView recordingStatus;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("ai_notebook", MODE_PRIVATE);
        currentTopic = prefs.getString("currentTopic", "My Notes");
        buildScreen();
        loadCurrent();
    }

    private int dp(int n) { return (int)(n * getResources().getDisplayMetrics().density); }
    private TextView text(String s, int size, int color) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setPadding(dp(4), dp(5), dp(4), dp(5));
        return t;
    }
    private Button button(String label) {
        Button b = new Button(this); b.setText(label); return b;
    }
    private void buildScreen() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(14), dp(18), dp(18));
        root.setBackgroundColor(Color.rgb(239,246,255));
        scroll.addView(root);

        TextView title = text("📘 AI NOTEBOOK", 26, Color.rgb(22,72,160));
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        root.addView(title);
        TextView sub = text("Your smart writing pen • Speak, organize, save", 14, Color.DKGRAY);
        sub.setGravity(Gravity.CENTER); root.addView(sub);

        status = text("Ready to write", 14, Color.rgb(22,72,160));
        root.addView(status);

        root.addView(text("TOPIC", 14, Color.rgb(22,72,160)));
        topicInput = new EditText(this);
        topicInput.setSingleLine(true);
        topicInput.setHint("Enter topic name");
        topicInput.setText(currentTopic);
        root.addView(topicInput, new LinearLayout.LayoutParams(-1, dp(52)));

        LinearLayout row = new LinearLayout(this);
        Button newTopic = button("＋ New topic");
        Button speak = button("🎙 Speak");
        row.addView(newTopic, new LinearLayout.LayoutParams(0, -2, 1));
        row.addView(speak, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(row);

        root.addView(text("YOUR NOTES", 14, Color.rgb(22,72,160)));
        notesInput = new EditText(this);
        notesInput.setGravity(Gravity.TOP | Gravity.START);
        notesInput.setMinLines(10);
        notesInput.setHint("Type here or tap Speak and talk. Your notes are saved on this phone.");
        notesInput.setTextSize(17);
        root.addView(notesInput, new LinearLayout.LayoutParams(-1, dp(280)));

        recordingStatus = text("Audio: ready", 14, Color.rgb(22,72,160));
        root.addView(text("VOICE RECORDING", 14, Color.rgb(22,72,160)));
        root.addView(recordingStatus);
        LinearLayout audioRow = new LinearLayout(this);
        Button record = button("🔴 Start recording");
        Button stop = button("⏹ Stop & save audio");
        Button play = button("▶ Play latest audio");
        audioRow.addView(record, new LinearLayout.LayoutParams(0, -2, 1));
        audioRow.addView(stop, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(audioRow);
        root.addView(play);

        Button save = button("💾 Save notes");
        root.addView(save);
        Button open = button("📂 Open saved notes");
        root.addView(open);
        Button share = button("↗ Share notes");
        root.addView(share);

        newTopic.setOnClickListener(v -> createTopic());
        speak.setOnClickListener(v -> startSpeech());
        record.setOnClickListener(v -> startRecording());
        stop.setOnClickListener(v -> stopRecording());
        play.setOnClickListener(v -> playLatestRecording());
        save.setOnClickListener(v -> saveCurrent());
        open.setOnClickListener(v -> openSaved());
        share.setOnClickListener(v -> shareNotes());

        setContentView(scroll);
    }

    private File recordingsDir() {
        File dir = new File(getFilesDir(), "recordings");
        if (!dir.exists()) dir.mkdirs();
        return dir;
    }
    private String safeTopic() {
        String t = topicInput.getText().toString().trim();
        if (t.isEmpty()) t = "My Notes";
        return t.replaceAll("[^A-Za-z0-9_-]", "_");
    }
    private void startRecording() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
            Toast.makeText(this, "Allow microphone permission, then tap Start recording again.", Toast.LENGTH_LONG).show();
            return;
        }
        if (recorder != null) return;
        String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        currentRecording = new File(recordingsDir(), safeTopic() + "_" + stamp + ".m4a");
        try {
            recorder = new MediaRecorder();
            recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
            recorder.setOutputFile(currentRecording.getAbsolutePath());
            recorder.prepare();
            recorder.start();
            recordingStatus.setText("Recording audio for: " + topicInput.getText().toString());
            status.setText("Recording. Tap Stop & save audio when finished.");
        } catch (Exception e) {
            if (recorder != null) { try { recorder.release(); } catch (Exception ignored) {} recorder = null; }
            if (currentRecording != null) currentRecording.delete();
            Toast.makeText(this, "Could not start recording. Check microphone permission.", Toast.LENGTH_LONG).show();
        }
    }
    private void stopRecording() {
        if (recorder == null) { Toast.makeText(this, "No recording is in progress.", Toast.LENGTH_SHORT).show(); return; }
        try { recorder.stop(); recordingStatus.setText("Audio saved for topic: " + topicInput.getText().toString()); status.setText("Audio saved on this phone."); Toast.makeText(this, "Audio recording saved", Toast.LENGTH_SHORT).show(); }
        catch (RuntimeException e) { if (currentRecording != null) currentRecording.delete(); Toast.makeText(this, "Recording was too short. Please try again.", Toast.LENGTH_LONG).show(); }
        finally { recorder.release(); recorder = null; }
    }
    private void playLatestRecording() {
        File[] files = recordingsDir().listFiles((dir, name) -> name.startsWith(safeTopic() + "_") && name.endsWith(".m4a"));
        if (files == null || files.length == 0) { Toast.makeText(this, "No saved audio for this topic yet.", Toast.LENGTH_LONG).show(); return; }
        File latest = files[0];
        for (File f : files) if (f.lastModified() > latest.lastModified()) latest = f;
        final File playbackFile = latest;
        try {
            if (player != null) { player.release(); player = null; }
            player = new MediaPlayer(); player.setDataSource(playbackFile.getAbsolutePath());
            player.setOnCompletionListener(mp -> { mp.release(); if (player == mp) player = null; recordingStatus.setText("Playback finished: " + playbackFile.getName()); });
            player.prepare(); player.start();
            recordingStatus.setText("Playing: " + latest.getName());
        } catch (IOException e) { Toast.makeText(this, "Could not play this recording.", Toast.LENGTH_LONG).show(); }
    }
    @Override protected void onDestroy() {
        if (recorder != null) { try { recorder.stop(); } catch (Exception ignored) {} recorder.release(); recorder = null; }
        if (player != null) { player.release(); player = null; }
        super.onDestroy();
    }

    private void createTopic() {
        saveCurrent();
        String next = topicInput.getText().toString().trim();
        if (next.isEmpty() || next.equals(currentTopic)) next = "Topic " + (prefs.getInt("topicCount", 1) + 1);
        currentTopic = next;
        prefs.edit().putInt("topicCount", prefs.getInt("topicCount", 1) + 1)
            .putString("currentTopic", currentTopic).apply();
        topicInput.setText(currentTopic);
        notesInput.setText("");
        status.setText("New topic created: " + currentTopic);
    }

    private void startSpeech() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "Speech recognition is not available on this phone.", Toast.LENGTH_LONG).show();
            return;
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
            return;
        }
        try {
            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
            intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak your notes. Say New topic to start another section.");
            intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
            startActivityForResult(intent, REQ_SPEECH);
        } catch (Exception e) {
            Toast.makeText(this, "Could not start speech recognition.", Toast.LENGTH_LONG).show();
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_SPEECH && resultCode == RESULT_OK && data != null) {
            ArrayList<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (results != null && !results.isEmpty()) {
                String spoken = results.get(0).trim();
                if (spoken.toLowerCase(Locale.ROOT).matches(".*\\bnew topic\\b.*")) {
                    String remainder = spoken.replaceAll("(?i)\\bnew topic\\b", "").trim();
                    createTopic();
                    if (!remainder.isEmpty()) notesInput.append(remainder + "\n");
                    status.setText("Voice command detected: new topic");
                } else {
                    if (notesInput.length() > 0) notesInput.append("\n");
                    notesInput.append(spoken);
                    status.setText("Speech added to notes. Tap Save notes.");
                }
            }
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_AUDIO && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) startSpeech();
        else if (requestCode == REQ_AUDIO) Toast.makeText(this, "Microphone permission is needed for speech notes.", Toast.LENGTH_LONG).show();
    }

    private String keyFor(String topic) { return "note_" + topic.trim().replaceAll("[^A-Za-z0-9_-]", "_"); }
    private void saveCurrent() {
        String topic = topicInput.getText().toString().trim();
        if (topic.isEmpty()) topic = "My Notes";
        currentTopic = topic;
        prefs.edit().putString(keyFor(currentTopic), notesInput.getText().toString())
            .putString("currentTopic", currentTopic).apply();
        status.setText("Saved on this phone: " + currentTopic);
        Toast.makeText(this, "Notes saved on this phone", Toast.LENGTH_SHORT).show();
    }
    private void loadCurrent() {
        notesInput.setText(prefs.getString(keyFor(currentTopic), ""));
    }
    private void openSaved() {
        String topic = topicInput.getText().toString().trim();
        if (topic.isEmpty()) topic = currentTopic;
        currentTopic = topic;
        notesInput.setText(prefs.getString(keyFor(topic), ""));
        status.setText("Opened saved topic: " + topic);
    }
    private void shareNotes() {
        String body = "AI Notebook — " + topicInput.getText().toString() + "\n\n" + notesInput.getText().toString();
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain"); send.putExtra(Intent.EXTRA_TEXT, body);
        startActivity(Intent.createChooser(send, "Share your notes"));
    }
}
