# AI Notebook — Smart Writing Pen

Android starter project built via GitHub Actions. Features include topic-based text notes, Android speech-to-text entry, spoken “New topic” command, local note saving, sharing, and manual audio recording saved privately on the phone with playback of the latest recording for the selected topic. The colorful AI Notebook launcher icon is included.

## Current limitations
- Audio recording currently uses Start Recording / Stop & Save; automatic speech-triggered recording is not yet implemented.
- Android speech recognition is invoked separately from audio recording; simultaneous continuous transcription and recording needs additional implementation/testing because microphone access can conflict.
- Audio stays in the app's private storage and can be removed if the app is uninstalled.
- Background recording after screen lock is not implemented yet.

Build with the GitHub Actions workflow.
